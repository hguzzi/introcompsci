x1=int(input('dammi un numero'))
# legge un numero e stampa ok se il numero e' pari
# ed e' maggiore di 20
#if(x1%2==0):
#    if(x1>20):
#        print('ok')
#    print('secondo if finito')
#print('primo if finito')
if(x1%2==0):
    if(x1>100):
        print('ok')
    else:
        print('no')
if(x1%2==0):
    if(x1>100):
        print('ok')
    if(x1<=100):
        print('no')
if(x1%2==0)and(x1>100):
    print('ok')
if(x1%2==0)and(x1<=100):
    print('ok')
        

    

