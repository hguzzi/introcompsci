def maggiore(x1,x2):
    if(x1>x2):
        return x1
    else: 
        return x2


def prodotto(x1,x2):
    z=x1*x2    
    print(z)
    
def prodotto2(x1,x2):
    z=x1*x2
    return z
   
prodotto(45,55)
y=prodotto2(4555,888)
print(y)
     

    

