def stampaciao():
    print('CIAO')

#stampaciao()
     

    

