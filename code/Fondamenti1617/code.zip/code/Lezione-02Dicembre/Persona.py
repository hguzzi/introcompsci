class Persona :
    def __init__(self,nome,cognome):
        self.n=nome
        self.c=cognome
    def getNome(self):
        return self.n
    def getCognome(self):
        return self.c
        

