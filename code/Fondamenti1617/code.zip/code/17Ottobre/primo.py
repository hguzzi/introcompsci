x = int(input('Dammi un numero'))
y = int(input('Dammi il secondo numero'))
z= x*y
print (z)

