prima=int(input('Prima Variabile'))
seconda=int(input('Seconda Variabile'))
prodotto=prima*seconda
potenza=prima**seconda
print(prodotto)
print(potenza)

