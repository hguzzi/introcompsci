# Programma legge tre valori da tastiera
# stampa a video somma e prodotto
x=int(input('Primo Valore'))
y=int(input('secondo valore'))
z=int(input('Terzo Valore'))
q=x+y+z
t=x*y*z
print(q)
print(t)