# due condizioni Separate
x=int(input('Leggi Valore'))
if((x%2)==0):
    print('Pari')

