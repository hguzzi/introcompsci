# due condizioni Separate
x=int(input('Leggi Valore'))
y=int(input('Leggi Valore'))
z=int(input('Leggi Valore'))
if((x==y) and (y==z) ):
    print('Tutti e tre uguali')

