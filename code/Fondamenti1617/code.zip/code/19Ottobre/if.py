# legge un valore e lo stampa
# se e' maggiore di zero
x=int(input('Leggi un Valore'))
if(x > 0):
    print(x)
    print('Fine')   
     
