# due condizioni Separate
x=int(input('Leggi Valore'))
if(x<10):
    print('Minore di Dieci')
if(x>20):
    print('Maggiore di Venti')
print('Fine')

