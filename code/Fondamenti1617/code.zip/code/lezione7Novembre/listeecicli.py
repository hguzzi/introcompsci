
def sommaelementi(l):
    acc=0
    for x in l:
        acc=acc+x
    return (acc)

def mediaelementi(l):
    acc=0
    for x in l:
        acc=acc+x
    media=acc/len(l)
    return media
# corretto?????    

# somma dei numeri pari 

def sommadeipari(l):
    acc=0
    for x in l:
        if(x%2==0):
            acc=acc+x
    return acc

    
#s=sommaelementi([12,323,432])
    
